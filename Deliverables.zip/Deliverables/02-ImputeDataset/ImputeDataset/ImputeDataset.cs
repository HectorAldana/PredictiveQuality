﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Configuration;


using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Diagnostics;
using System.Timers;
using System.Globalization;
using System.Net;
using System.Net.Sockets;


namespace ImputeDataset
{
    class ImputeDataset
    {
        static void Main(string[] args)
        {
            DataSet dsProductRuns;
            
            string queryString = "SELECT Product,MfgLine,MfgDate,Shift FROM Dataset02 ";
            
            string product = "";
            string mfgLine = "";
            string mfgDate = "";
            string shift = "";
            string startUpPF = "0";
            string operationalPF = "1";
            int startUpSteps = 107;
            int operationalSteps = 73;

            try
            {
                GetSettings();

                Console.WriteLine("Impute process starts...");
                dsProductRuns = SQLUtility.GetDataSet(queryString, Globals.ConnectionString);
                foreach (DataRow dsProductRun in dsProductRuns.Tables[0].Rows)
                {
                    product = dsProductRun["Product"].ToString();
                    mfgLine = dsProductRun["MfgLine"].ToString();
                    mfgDate = dsProductRun["MfgDate"].ToString();
                    shift = dsProductRun["Shift"].ToString();

                    Impute(startUpPF, product, mfgLine, mfgDate, shift, startUpSteps);
                    Impute(operationalPF, product, mfgLine, mfgDate, shift, operationalSteps);

                }
                Console.WriteLine("Impute process ends...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                SQLUtility.LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
            }
            finally
            {
                
            }
        }

        private static void Impute(string pfTypeId, string product, string mfgLine, string mfgDate, string shift, int steps)
        {
            int sequence = -1;
            string column;
            string queryString = "";
            DataSet dsCenter;
            string SQLUpdate = "";
            string center = "";

            for (sequence = 1; sequence <= steps; sequence++)
            {
                queryString = "DECLARE @Center numeric(18, 3); ";
                queryString = queryString + "EXEC sp_GetCenter ";
                queryString = queryString + "@Product = N'" + product + "',";
                queryString = queryString + "@MfgLine = " + mfgLine + ", ";
                queryString = queryString + "@PFType = " + pfTypeId + ", ";
                queryString = queryString + "@Sequence = " + sequence + ", ";
                queryString = queryString + "@Center = @Center OUTPUT; ";
                //queryString = queryString + "SELECT  @Center as N'Center'; ";
                dsCenter = SQLUtility.GetDataSet(queryString, Globals.ConnectionString);

                foreach (DataRow dsCenterRow in dsCenter.Tables[0].Rows)
                {
                    center = dsCenterRow["Column1"].ToString();
                }
                if (center!="") 
                {
                    column = "T" + pfTypeId + "_" + sequence;
                    SQLUpdate = "UPDATE Dataset02 SET " + column + " = " + center;
                    SQLUpdate = SQLUpdate + " WHERE Product = '" + product + "' AND MfgLine = " + mfgLine + " AND MfgDate = '" + mfgDate + "' AND Shift = " + shift + " AND " + column + " IS NULL";
                    Console.WriteLine("Product: '" + product + "' MfgLine: " + mfgLine + " MfgDate: '" + mfgDate + "' Shift: " + shift + " Sequence: " + sequence + " pfTypeId: " + pfTypeId + " center: " + center);
                    SQLUtility.ExecSQLCommand(SQLUpdate, Globals.ConnectionString);
                }
            }
        }
        private static void GetSettings()
        {
            Console.WriteLine("Getting settings...");
            Globals.ConnectionString = ConfigurationManager.ConnectionStrings["Manufacturing"].ToString();

        }

    }
}
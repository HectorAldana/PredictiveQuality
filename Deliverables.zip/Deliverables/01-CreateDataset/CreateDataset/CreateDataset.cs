﻿using System.Configuration;
using System.Data;


namespace CreateDataset
{
    class CreateDataset
    {
        static void Main(string[] args)
        {
            DataSet ds;
            string queryString = "";

            string product = "";
            string mfgLine = "";
            string mfgDate = "";
            string shift = "";
            string pfTypeId = "";
            string sequence = "";
            string sampleData = "";
            string response = "";
            string column = "";
            string SQLInsert = "";
            string SQLUpdate = "";
            int sw = -1;

            try
            {
                GetSettings();
                Console.WriteLine("Create Data Set 02 process starts...");
                queryString = "SELECT PFITEMID AS Product, WorkcenterId AS MfgLine, MfgDate, Shift, PFTypeId, Sequence, SampleData, COALESCE(Response,0) AS Response ";
                queryString = queryString + " FROM Dataset01 ";
                queryString = queryString + " WHERE  PFITEMID IS NOT NULL AND WorkcenterId IS NOT NULL AND MfgDate IS NOT NULL AND Shift IS NOT NULL AND PFTypeId IS NOT NULL AND  Sequence IS NOT NULL AND SampleData IS NOT NULL ";
                queryString = queryString + " ORDER BY PFITEMID, WorkcenterId, MfgDate, Shift, PFTypeId, Sequence ";
                ds = SQLUtility.GetDataSet(queryString, Globals.ConnectionString);
                foreach (DataRow dsRow in ds.Tables[0].Rows)
                {
                    product = dsRow["Product"].ToString();
                    mfgLine = dsRow["MfgLine"].ToString();
                    mfgDate = dsRow["MfgDate"].ToString();
                    shift = dsRow["Shift"].ToString();
                    pfTypeId = dsRow["PFTypeId"].ToString();
                    sequence = dsRow["Sequence"].ToString().Trim();
                    sampleData = dsRow["SampleData"].ToString();
                    response = dsRow["Response"].ToString();

                    if (pfTypeId == "0")
                    {
                        column = "T0_" + sequence;
                        sw = 0;
                    }
                    else if (pfTypeId == "1")
                    {
                        column = "T1_" + sequence;
                        sw = 0;
                    }
                    else 
                    {
                        sw = 1;
                    }

                    if (sw == 1)
                    {
                        //Do nothing
                    }
                    else 
                    {
                        SQLInsert = "INSERT INTO Dataset02 (Product,MfgLine,MfgDate,Shift,";
                        SQLInsert = SQLInsert + column + ", Response) VALUES (''" + product + "'', " + mfgLine + ", ''" + mfgDate + "'', " + shift + ", " + sampleData + ", " + response + ")";

                        SQLUpdate = "UPDATE Dataset02 SET ";
                        SQLUpdate = SQLUpdate + column + " = " + sampleData + ", Response = " + response;
                        SQLUpdate = SQLUpdate + " WHERE Product = ''" + product + "'' AND MfgLine = " + mfgLine + " AND MfgDate = ''" + mfgDate + "'' AND Shift = " + shift;

                        queryString = "EXECUTE sp_AddSample ";
                        queryString = queryString + "@PFITEMId = '" + product + "'";
                        queryString = queryString + ",@MfgLine = " + mfgLine;
                        queryString = queryString + ",@MfgDate = '" + mfgDate + "'";
                        queryString = queryString + ",@Shift = " + shift;
                        queryString = queryString + ",@sqlInsert = '" + SQLInsert + "'";
                        queryString = queryString + ",@sqlUpdate= '" + SQLUpdate + "'";

                        Console.WriteLine("Product: '" + product + "' MfgLine: " + mfgLine + " MfgDate: '" + mfgDate + "' Shift: " + shift);

                        SQLUtility.ExecSQLCommand(queryString, Globals.ConnectionString);
                    }
                }
                Console.WriteLine("Create dataset process ends...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                SQLUtility.LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
            }
            finally
            {
                
            }
        }

        private static void GetSettings()
        {
            Console.WriteLine("Getting settings...");
            Globals.ConnectionString = ConfigurationManager.ConnectionStrings["Manufacturing"].ToString();

        }
    }
}
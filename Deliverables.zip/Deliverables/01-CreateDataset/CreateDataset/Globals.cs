﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Diagnostics;

namespace CreateDataset
{
    public static class Globals
    {
        #region "Examples"
        //public const Int32 BUFFER_SIZE = 512; // Unmodifiable
        //public static String FILE_NAME = "Output.txt"; // Modifiable
        //public static readonly String CODE_PREFIX = "US-"; // Unmodifiable
        #endregion

        #region "Database Connection"
        public static string ConnectionString = "";
        #endregion

        #region"Process"
        public static string msg = "";
        #endregion



    }
}

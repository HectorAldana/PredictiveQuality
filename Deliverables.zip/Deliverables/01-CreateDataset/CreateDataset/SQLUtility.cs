﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Diagnostics;




namespace CreateDataset
{
    public static class SQLUtility
    {


        public static Boolean ExecSQLCommand(string queryString, string connectionString)
        {
            Boolean result = false;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(queryString, connection);
                    command.Connection.Open();
                    command.ExecuteNonQuery();
                    command.Connection.Close();
                }
                result = true;
            }
            catch (SqlException sqlex)
            {
                Console.WriteLine("SQL Error: " + sqlex.ToString());
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + sqlex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + sqlex.Message, EventLogEntryType.Error);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.ToString());
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + ex.Message, EventLogEntryType.Error);
            }
            return result;
        }

        public static DataSet GetDataSet(string queryString, string connectionString)
        {
            SqlDataAdapter daSQL = null;
            DataSet dsSQL = new DataSet();
            SqlDataAdapter sqlAdapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    command = new SqlCommand(queryString, connection);
                    command.Connection.Open();

                    daSQL = new SqlDataAdapter(command);
                    daSQL.Fill(dsSQL);
                    command.Connection.Close();
                }
            }
            catch (SqlException sqlex)
            {
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + sqlex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + sqlex.Message, EventLogEntryType.Error);
            }
            catch (Exception ex)
            {
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + ex.Message, EventLogEntryType.Error);
            }
            finally
            {
                sqlAdapter.Dispose();
                command.Dispose();
            }
            return dsSQL;
        }

        public static DataTable GetDataTable(string queryString, string connectionString)
        {
            DataTable dtSQL = null;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter();
            SqlCommand command = new SqlCommand();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    command = new SqlCommand(queryString, connection);
                    command.Connection.Open();
                    sqlAdapter.SelectCommand = command;
                    sqlAdapter.Fill(dtSQL);
                    command.Connection.Close();
                }
            }
            catch (SqlException sqlex)
            {
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + sqlex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + sqlex.Message, EventLogEntryType.Error);
            }
            catch (Exception ex)
            {
                LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + ex.Message, EventLogEntryType.Error);
            }
            finally
            {
                sqlAdapter.Dispose();
                command.Dispose();
            }
            return dtSQL;
        }


      

        public static void LogError(string ErrorStr, string connectionString)
        {
            Console.WriteLine("Error: " + ErrorStr);
            string queryString = "";
            SqlCommand cmd = new SqlCommand();
            try
            {
                queryString = "EXECUTE sp_InsertError '" + ErrorStr + "' ";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(queryString, connection);
                    command.Connection.Open();
                    command.ExecuteNonQuery();
                    command.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                LogEvent(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                + ex.Message, EventLogEntryType.Error);
            }


        }

        public static void LogEvent(string str, EventLogEntryType EntryType)
        {
            try
            {

                System.Diagnostics.EventLog AppEventLog = new System.Diagnostics.EventLog();
                Assembly assembly = Assembly.GetExecutingAssembly();
                FileVersionInfo fileVersionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
                string strSource = fileVersionInfo.ProductName.ToString();

                const string strLogName = "Application";
                AppEventLog.Source = strSource;
                AppEventLog.Log = strLogName;

                // EventLog is Shared Instance
                if (EventLog.SourceExists(strSource))
                {
                    // "." = Local Computer
                    if ((EventLog.LogNameFromSourceName(strSource, ".") == strLogName))
                    {
                        // do nothing
                    }
                    else
                    {
                        // .DeleteEventSource - Deletes REGISTRATION Of Source
                        EventLog.DeleteEventSource(strSource);
                        // Application, Security and System are Windows reserved Logs.
                        if (((strLogName != "Application")
                                    && ((strLogName != "Security")
                                    && (strLogName != "System"))))
                        {
                            // .Delete - removes log file
                            EventLog.Delete(strLogName);
                        }
                        else
                        {
                            // do nothing
                        }

                        // If strLogName <> ...
                        // .CreateEventSource Registers and Creates Custom Log
                        EventLog.CreateEventSource(strSource, strLogName);
                    }

                    // EventLog.LogNameFromSourceName(...
                }
                else
                {
                    // .CreateEventSource Creates and Registers Log File
                    EventLog.CreateEventSource(strSource, strLogName);
                }

                // EventLog.SourceExists(strSource) 
                // This method of .WriteEntry is NOT a Shared Member of EventLog
                // Some are, Some are NOT
                AppEventLog.WriteEntry(str, EntryType);
                // RaiseEvent ErrorRaise(strErrString)

            }
            catch (Exception ex)
            {
                // Do nothing
            }

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Configuration;


using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Diagnostics;
using System.Timers;
using System.Globalization;
using System.Net;
using System.Net.Sockets;


namespace FeatureSelection
{
    class FeatureSelection
    {


        static void Main(string[] args)
        {
            DataSet dsOutputs;

            string queryString = "SELECT PFItemId AS Product,	PFWorkcenterId AS MfgLine,	PFTypeId,	Sequence,	AttributeId	 ";
            queryString = queryString + "FROM ProcessFlows ";
            queryString = queryString + "WHERE AttributeId IS NOT NULL ";
            queryString = queryString + "ORDER BY PFItemId,	PFWorkcenterId,	PFTypeId,	Sequence,	AttributeId";
            
            string product = "";
            string mfgLine = "";
            string pfTypeId = "";
            string sequence = "";

            try
            {
                GetSettings();

                Console.WriteLine("Feature selection process starts...");
                dsOutputs = SQLUtility.GetDataSet(queryString, Globals.ConnectionString);
                foreach (DataRow dsOutput in dsOutputs.Tables[0].Rows)
                {
                    product = dsOutput["Product"].ToString();
                    mfgLine = dsOutput["MfgLine"].ToString();
                    pfTypeId = dsOutput["PFTypeId"].ToString();
                    sequence = dsOutput["sequence"].ToString();

                    RemoveOuput(pfTypeId, product, mfgLine, sequence);


                }
                Console.WriteLine("Feature selection process ends...");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                SQLUtility.LogError(System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "."
                                  + System.Reflection.MethodBase.GetCurrentMethod().Name + ":  "
                                  + ex.Message, Globals.ConnectionString);
            }
            finally
            {
                
            }
        }

        private static void GetSettings()
        {
            Console.WriteLine("Getting settings...");
            Globals.ConnectionString = ConfigurationManager.ConnectionStrings["Manufacturing"].ToString();

        }

        private static void RemoveOuput(string pfTypeId, string product, string mfgLine, string sequence)
        {
            
            string column;
            string SQLUpdate = "";

            column = "T" + pfTypeId + "_" + sequence;
            SQLUpdate = "UPDATE Dataset02 SET " + column + " = NULL " ;
            SQLUpdate = SQLUpdate + " WHERE Product = '" + product + "' AND MfgLine = " + mfgLine ;
            Console.WriteLine("Product: '" + product + "' MfgLine: " + mfgLine + " PFTypeId: " + pfTypeId + " Sequence: " + sequence);

            SQLUtility.ExecSQLCommand(SQLUpdate, Globals.ConnectionString);

        }
    }
}